
package Login;

import java.sql.Connection;
import Model.NhanKhauModel;

public class NhanKhauController {
       private Connection conn;
      

    public NhanKhauController() {
    }
       
    public boolean addNhanKhau(NhanKhauModel b){
            return false;
    }
}
